
import 'package:flutter/material.dart';

import '../data/bank_inherited.dart';

class FormScreen extends StatefulWidget {
  const FormScreen({super.key, required this.bankContext});

  final BuildContext bankContext;

  @override
  State<FormScreen> createState() => _FormScreenState();
}

class _FormScreenState extends State<FormScreen> {
  TextEditingController contaController = TextEditingController();
  TextEditingController valorController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  bool valueValidator(String? value) {
    if (value != null && value.isEmpty) {
      return true;
    }
    return false;
  }


  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Nova Transferencia'),
          backgroundColor: Colors.pink,
        ),
        body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 50),
                      child: Icon(
                        Icons.attach_money
                      ),
                    )
                    ,
                    Padding(padding: const EdgeInsets.only(top: 50),
                      child:
                      Text(
                        'Formulario aqui: ',
                        style: TextStyle(fontSize: 15, color: Colors.black),
                      ),
                    ),

                  ],
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    validator: (String? value) {
                      if (valueValidator(value)) {
                        return 'Insira a conta';
                      }
                      return null;
                    },
                    controller: contaController,
                    textAlign: TextAlign.start,
                    decoration: InputDecoration(
                      hintText: 'Conta',
                      labelText: 'Insira a conta'
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    onChanged: (text) {
                      setState(() {});
                    },
                    validator: (String? value) {
                      if (valueValidator(value)) {
                        return 'Insira o valor';
                      }
                      return null;
                    },
                    controller: valorController,
                    textAlign: TextAlign.start,
                    decoration: InputDecoration(

                      hintText: 'Valor',
                        labelText: 'Insira o valor'
                    ),
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      BankInherited.of(widget.bankContext).newBank(
                          contaController.text,
                          valorController.text,
                      );
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Criando uma nova transferencia'),
                        ),
                      );
                      Navigator.pop(context);
                    }
                  },
                  child: Text('Submit!'),

                ),
              ],
            ),
          ),
        ),
    );
  }
}
