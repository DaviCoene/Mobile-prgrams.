import 'package:flutter/material.dart';

class Bank extends StatefulWidget {
  final String conta;
  final String valor;

  Bank(this.conta, this.valor, {super.key});


  @override
  State<Bank> createState() => _BankState();
}

class _BankState extends State<Bank> {



  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(4.0),
      child: Container(

        child: Stack(


          children: [
            Container(
              height: 100,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.grey,
              ),


            ),
            Container(
              height: 90,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white60,
              ),
            ),
            Row(


                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(padding: const EdgeInsets.all(20),
                    child:
                    Icon(
                      Icons.attach_money,color: Colors.amber,
                    ),

                  ),
                  Column(
                    children: [
                      Padding(padding: const EdgeInsets.only(top: 20, right: 50),
                        child:
                        Text(
                          widget.conta,
                        ),

                      ),
                      Padding(padding: const EdgeInsets.only(right: 50),
                        child:
                        Text(
                          widget.valor,
                          style: TextStyle(fontSize: 10, color: Colors.black26),
                        ),
                      ),

                    ],
                  )



                ]
            )
          ],

        ),


      ),
    );
  }
}
