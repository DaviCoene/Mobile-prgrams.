
import 'package:flutter/material.dart';

import '../model/bank.dart';

class BankInherited extends InheritedWidget {
  BankInherited({
    super.key,
    required Widget child,
  }) : super(child: child);

  @override
  bool updateShouldNotify(BankInherited oldWidget) {
    return oldWidget.BankList.length != BankList.length;
  }

  void newBank (String conta, String valor){
    BankList.add(Bank(conta, valor));
  }

  final List<Bank> BankList = [
    Bank('5000', '1145.15'),
    Bank('7000', '17500.04'),

  ];



  static BankInherited of(BuildContext context) {
    final BankInherited? result = context.dependOnInheritedWidgetOfExactType<BankInherited>();
    assert(result != null, 'No BankInherited found in context');
    return result!;
  }


}
