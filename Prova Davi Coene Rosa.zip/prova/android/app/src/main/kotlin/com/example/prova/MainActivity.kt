package com.example.prova

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
